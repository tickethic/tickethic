#!/bin/bash

# Script pour configurer tickethic.ch avec SSL dans le conteneur Nginx existant
set -e

echo "🚀 Configuration de tickethic.ch avec SSL..."

# Vérifier que le DNS est configuré
echo "🔍 Vérification du DNS..."
if ! nslookup tickethic.ch | grep -q "46.62.129.49"; then
    echo "❌ DNS non configuré. Veuillez configurer :"
    echo "   A record: tickethic.ch → 46.62.129.49"
    echo "   A record: www.tickethic.ch → 46.62.129.49"
    exit 1
fi
echo "✅ DNS configuré"

# Copier la nouvelle configuration Nginx
echo "🔧 Mise à jour de la configuration Nginx..."
docker cp nginx-tickethic-update.conf nginx-proxy:/etc/nginx/nginx.conf

# Tester la configuration Nginx
echo "🧪 Test de la configuration Nginx..."
docker exec nginx-proxy nginx -t

# Recharger Nginx
echo "🔄 Rechargement de Nginx..."
docker exec nginx-proxy nginx -s reload

# Générer le certificat SSL pour tickethic.ch
echo "🔐 Génération du certificat SSL pour tickethic.ch..."
certbot certonly --webroot -w /var/www/certbot -d tickethic.ch -d www.tickethic.ch --non-interactive --agree-tos --email admin@tickethic.ch

# Copier les certificats dans le conteneur Nginx
echo "📋 Copie des certificats dans le conteneur..."
docker cp /etc/letsencrypt/live/tickethic.ch nginx-proxy:/etc/letsencrypt/live/

# Recharger Nginx avec le nouveau certificat
echo "🔄 Rechargement final de Nginx..."
docker exec nginx-proxy nginx -s reload

echo "✅ Configuration terminée !"
echo "🌐 Votre site Tickethic est accessible sur :"
echo "   - https://tickethic.ch"
echo "   - https://www.tickethic.ch"
echo "   - http://tickethic.ch (redirige vers HTTPS)"

