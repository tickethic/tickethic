#!/bin/bash

# Script pour configurer tickethic.ch avec certificats temporaires
set -e

echo "🚀 Configuration de tickethic.ch avec certificats temporaires..."

# Créer le dossier SSL
echo "📁 Création du dossier SSL..."
mkdir -p /root/host-calendars-hub/nginx/ssl

# Générer des certificats auto-signés temporaires
echo "🔐 Génération de certificats temporaires..."

# Certificat pour viladolina.online
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /root/host-calendars-hub/nginx/ssl/viladolina.online.key \
    -out /root/host-calendars-hub/nginx/ssl/viladolina.online.crt \
    -subj "/C=CH/ST=CH/L=Zurich/O=VilaDolina/CN=viladolina.online"

# Certificat pour tickethic.ch
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /root/host-calendars-hub/nginx/ssl/tickethic.ch.key \
    -out /root/host-calendars-hub/nginx/ssl/tickethic.ch.crt \
    -subj "/C=CH/ST=CH/L=Zurich/O=Tickethic/CN=tickethic.ch"

echo "✅ Certificats générés"

# Copier la nouvelle configuration Nginx
echo "🔧 Mise à jour de la configuration Nginx..."
cp /root/nginx-tickethic-simple.conf /root/host-calendars-hub/nginx/nginx.conf

# Tester la configuration Nginx
echo "🧪 Test de la configuration Nginx..."
docker exec nginx-proxy nginx -t

# Recharger Nginx
echo "🔄 Rechargement de Nginx..."
docker exec nginx-proxy nginx -s reload

echo "✅ Configuration terminée !"
echo "🌐 Votre site Tickethic est accessible sur :"
echo "   - https://tickethic.ch (certificat temporaire)"
echo "   - https://www.tickethic.ch (certificat temporaire)"
echo "   - http://tickethic.ch (redirige vers HTTPS)"
echo ""
echo "⚠️  Note: Les certificats sont temporaires (auto-signés)"
echo "   Pour des certificats valides, utilisez Let's Encrypt plus tard"

