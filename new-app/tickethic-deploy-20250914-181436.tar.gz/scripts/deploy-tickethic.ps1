# Script PowerShell pour déployer Tickethic DApp sur le serveur de production
param(
    [string]$ServerHost = "46.62.129.49",
    [string]$ServerUser = "root",
    [string]$RemotePath = "/root/tickethic-dapp",
    [string]$LocalPort = "3001",
    [string]$SshKey = "C:\Users\vujic\.ssh\id_ed25519"
)

Write-Host "Deploiement de Tickethic DApp sur le serveur..." -ForegroundColor Green

# Vérifier la connexion SSH
Write-Host "Verification de la connexion SSH..." -ForegroundColor Yellow
ssh -i $SshKey -o ConnectTimeout=10 "$ServerUser@$ServerHost" "echo 'Connexion SSH OK'"
if ($LASTEXITCODE -ne 0) {
    Write-Host "Impossible de se connecter au serveur" -ForegroundColor Red
    exit 1
}
Write-Host "Connexion SSH OK" -ForegroundColor Green

# Créer le dossier sur le serveur
Write-Host "Creation du dossier sur le serveur..." -ForegroundColor Yellow
ssh -i $SshKey "$ServerUser@$ServerHost" "mkdir -p $RemotePath"

# Créer un archive temporaire
$tempArchive = "tickethic-deploy-$(Get-Date -Format 'yyyyMMdd-HHmmss').tar.gz"
Write-Host "Creation de l'archive..." -ForegroundColor Yellow
# Inclure .env.local s'il existe
if (Test-Path ".env.local") {
    Write-Host "Inclusion du fichier .env.local dans l'archive" -ForegroundColor Yellow
}
tar -czf $tempArchive --exclude=node_modules --exclude=.next --exclude=.git --exclude="*.log" --exclude="*.tar.gz" .

# Copier l'archive sur le serveur
Write-Host "Copie de l'archive vers le serveur..." -ForegroundColor Yellow
scp -i $SshKey $tempArchive "$ServerUser@$ServerHost`:/root/"

# Déployer sur le serveur
Write-Host "Deploiement sur le serveur..." -ForegroundColor Yellow
ssh -i $SshKey "$ServerUser@$ServerHost" "
    # Arrêter et supprimer les conteneurs existants s'ils existent
    if [ -d /root/tickethic-dapp ]; then
        cd /root/tickethic-dapp
        docker-compose down 2>/dev/null || true
        cd /root
        rm -rf tickethic-dapp
    fi
    
    # Créer le nouveau dossier et extraire l'archive
    mkdir -p tickethic-dapp
    cd tickethic-dapp
    tar -xzf /root/$tempArchive
    
    # Démarrer les nouveaux conteneurs
    docker-compose up -d --build
"

# Attendre que les conteneurs soient prêts
Write-Host "Attente du demarrage des conteneurs..." -ForegroundColor Yellow
Start-Sleep -Seconds 10

# Connecter au réseau Nginx
Write-Host "Connexion au reseau Nginx..." -ForegroundColor Yellow
ssh -i $SshKey "$ServerUser@$ServerHost" "docker network connect host-calendars-hub_host-calendars-network tickethic-dapp 2>/dev/null || echo 'Reseau deja connecte ou non disponible'"

# Nettoyer
Remove-Item $tempArchive -ErrorAction SilentlyContinue

Write-Host "Deploiement termine!" -ForegroundColor Green
Write-Host "Application accessible sur: https://tickethic.ch" -ForegroundColor Cyan
Write-Host "Acces direct: http://$ServerHost`:$LocalPort" -ForegroundColor Cyan
