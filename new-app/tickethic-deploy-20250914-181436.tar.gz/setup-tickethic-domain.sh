#!/bin/bash

# Script pour configurer tickethic.ch avec SSL
set -e

echo "🚀 Configuration de tickethic.ch avec SSL..."

# Vérifier que le DNS est configuré
echo "🔍 Vérification du DNS..."
if ! nslookup tickethic.ch | grep -q "46.62.129.49"; then
    echo "❌ DNS non configuré. Veuillez configurer :"
    echo "   A record: tickethic.ch → 46.62.129.49"
    echo "   A record: www.tickethic.ch → 46.62.129.49"
    echo "   Attendez la propagation DNS (5-30 min) puis relancez ce script"
    exit 1
fi
echo "✅ DNS configuré"

# Activer le site Nginx
echo "🔧 Activation du site Nginx..."
ln -sf /etc/nginx/sites-available/nginx-tickethic.conf /etc/nginx/sites-enabled/

# Tester la configuration Nginx
echo "🧪 Test de la configuration Nginx..."
nginx -t

# Redémarrer Nginx
echo "🔄 Redémarrage de Nginx..."
systemctl reload nginx

# Générer le certificat SSL
echo "🔐 Génération du certificat SSL..."
certbot certonly --nginx -d tickethic.ch -d www.tickethic.ch --non-interactive --agree-tos --email admin@tickethic.ch

# Recharger Nginx avec le nouveau certificat
echo "🔄 Rechargement de Nginx avec SSL..."
systemctl reload nginx

echo "✅ Configuration terminée !"
echo "🌐 Votre site est accessible sur :"
echo "   - http://tickethic.ch (redirige vers HTTPS)"
echo "   - https://tickethic.ch"
echo "   - https://www.tickethic.ch"

