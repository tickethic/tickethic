# Script de déploiement PowerShell pour Tickethic DApp
Write-Host "🚀 Déploiement de Tickethic DApp..." -ForegroundColor Green

# Vérifier si Docker est installé
try {
    docker --version | Out-Null
    Write-Host "✅ Docker détecté" -ForegroundColor Green
} catch {
    Write-Host "❌ Docker n'est pas installé. Veuillez l'installer d'abord." -ForegroundColor Red
    exit 1
}

# Vérifier si docker-compose est installé
try {
    docker-compose --version | Out-Null
    Write-Host "✅ Docker Compose détecté" -ForegroundColor Green
} catch {
    Write-Host "❌ Docker Compose n'est pas installé. Veuillez l'installer d'abord." -ForegroundColor Red
    exit 1
}

# Arrêter les conteneurs existants
Write-Host "🛑 Arrêt des conteneurs existants..." -ForegroundColor Yellow
docker-compose down

# Construire et démarrer les nouveaux conteneurs
Write-Host "🔨 Construction et démarrage des conteneurs..." -ForegroundColor Yellow
docker-compose up --build -d

# Vérifier le statut
Write-Host "📊 Vérification du statut..." -ForegroundColor Yellow
docker-compose ps

Write-Host "✅ Déploiement terminé!" -ForegroundColor Green
Write-Host "🌐 L'application est accessible sur http://localhost:3001" -ForegroundColor Cyan
Write-Host "📝 Pour voir les logs: docker-compose logs -f" -ForegroundColor Cyan
Write-Host "🛑 Pour arrêter: docker-compose down" -ForegroundColor Cyan
