#!/bin/bash

# Script de déploiement pour Tickethic DApp
echo "🚀 Déploiement de Tickethic DApp..."

# Vérifier si Docker est installé
if ! command -v docker &> /dev/null; then
    echo "❌ Docker n'est pas installé. Veuillez l'installer d'abord."
    exit 1
fi

# Vérifier si docker-compose est installé
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose n'est pas installé. Veuillez l'installer d'abord."
    exit 1
fi

# Arrêter les conteneurs existants
echo "🛑 Arrêt des conteneurs existants..."
docker-compose down

# Construire et démarrer les nouveaux conteneurs
echo "🔨 Construction et démarrage des conteneurs..."
docker-compose up --build -d

# Vérifier le statut
echo "📊 Vérification du statut..."
docker-compose ps

echo "✅ Déploiement terminé!"
echo "🌐 L'application est accessible sur http://localhost:3001"
echo "📝 Pour voir les logs: docker-compose logs -f"
echo "🛑 Pour arrêter: docker-compose down"
