#!/bin/bash

# Script pour configurer Let's Encrypt SSL pour tickethic.ch
set -e

echo "🔐 Configuration de Let's Encrypt SSL pour tickethic.ch..."

# Vérifier que le DNS est configuré
echo "🔍 Vérification du DNS..."
if ! nslookup tickethic.ch | grep -q "46.62.129.49"; then
    echo "❌ DNS non configuré"
    exit 1
fi
echo "✅ DNS configuré"

# Créer le dossier pour les certificats
echo "📁 Création des dossiers..."
mkdir -p /root/host-calendars-hub/certbot/conf/live

# Générer les certificats Let's Encrypt
echo "🔐 Génération des certificats Let's Encrypt..."

# Arrêter temporairement Nginx pour libérer le port 80
echo "⏸️ Arrêt temporaire de Nginx..."
docker stop nginx-proxy

# Générer les certificats
certbot certonly --standalone \
    -d tickethic.ch \
    -d www.tickethic.ch \
    --non-interactive \
    --agree-tos \
    --email admin@tickethic.ch

# Copier les certificats dans le dossier monté
echo "📋 Copie des certificats..."
cp -r /etc/letsencrypt/live/tickethic.ch /root/host-calendars-hub/certbot/conf/live/

# Mettre à jour la configuration Nginx pour utiliser les vrais certificats
echo "🔧 Mise à jour de la configuration Nginx..."
cat > /root/host-calendars-hub/nginx/nginx.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Logging
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;

    # SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Upstream to Node.js apps
    upstream viladolina_app {
        server host-calendars-hub:3000;
    }

    upstream tickethic_app {
        server tickethic-dapp:3000;
    }

    # HTTP server - redirect to HTTPS
    server {
        listen 80;
        server_name viladolina.online www.viladolina.online tickethic.ch www.tickethic.ch;

        # Let's Encrypt challenge
        location /.well-known/acme-challenge/ {
            root /var/www/certbot;
        }

        # Redirect all HTTP traffic to HTTPS
        location / {
            return 301 https://$server_name$request_uri;
        }
    }

    # HTTPS server - Vila Dolina
    server {
        listen 443 ssl http2;
        server_name viladolina.online www.viladolina.online;

        # SSL certificates temporaires
        ssl_certificate /etc/nginx/ssl/viladolina.online.crt;
        ssl_certificate_key /etc/nginx/ssl/viladolina.online.key;

        # Security headers
        add_header X-Frame-Options DENY;
        add_header X-Content-Type-Options nosniff;
        add_header X-XSS-Protection "1; mode=block";
        add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

        # Proxy to Vila Dolina app
        location / {
            proxy_pass http://viladolina_app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;

            # Timeouts
            proxy_connect_timeout 60s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        # API rate limiting
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            proxy_pass http://viladolina_app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }

        # Static files caching
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
            proxy_pass http://viladolina_app;
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }

    # HTTPS server - Tickethic avec certificats Let's Encrypt
    server {
        listen 443 ssl http2;
        server_name tickethic.ch www.tickethic.ch;

        # SSL certificates Let's Encrypt
        ssl_certificate /etc/letsencrypt/live/tickethic.ch/fullchain.pem;
        ssl_certificate_key /etc/letsencrypt/live/tickethic.ch/privkey.pem;

        # Security headers
        add_header X-Frame-Options DENY;
        add_header X-Content-Type-Options nosniff;
        add_header X-XSS-Protection "1; mode=block";
        add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

        # Proxy to Tickethic app
        location / {
            proxy_pass http://tickethic_app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;

            # Timeouts
            proxy_connect_timeout 60s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        # API rate limiting
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            proxy_pass http://tickethic_app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }

        # Static files caching
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
            proxy_pass http://tickethic_app;
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }
}
EOF

# Redémarrer Nginx
echo "🔄 Redémarrage de Nginx..."
docker start nginx-proxy

# Tester la configuration
echo "🧪 Test de la configuration..."
sleep 5
docker exec nginx-proxy nginx -t

echo "✅ Configuration terminée !"
echo "🌐 Votre site Tickethic est maintenant accessible avec des certificats SSL valides :"
echo "   - https://tickethic.ch ✅ (certificat Let's Encrypt)"
echo "   - https://www.tickethic.ch ✅ (certificat Let's Encrypt)"
echo ""
echo "🔒 Les certificats sont valides et renouvelés automatiquement !"
