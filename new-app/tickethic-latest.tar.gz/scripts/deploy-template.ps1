# Script PowerShell template pour déployer Tickethic DApp
# Copiez ce fichier et modifiez les paramètres selon votre serveur

param(
    [string]$ServerHost = "YOUR_SERVER_IP_OR_DOMAIN",
    [string]$ServerUser = "YOUR_USERNAME",
    [string]$RemotePath = "/path/to/your/app",
    [string]$LocalPort = "3001",
    [string]$SshKey = "C:\Users\YOUR_USER\.ssh\YOUR_KEY"
)

Write-Host "Deploiement de Tickethic DApp sur le serveur..." -ForegroundColor Green

# Verifier la connexion SSH
Write-Host "Verification de la connexion SSH..." -ForegroundColor Yellow
ssh -i $SshKey -o ConnectTimeout=10 "$ServerUser@$ServerHost" "echo 'Connexion SSH OK'"
if ($LASTEXITCODE -ne 0) {
    Write-Host "Impossible de se connecter au serveur" -ForegroundColor Red
    exit 1
}
Write-Host "Connexion SSH OK" -ForegroundColor Green

# Creer le dossier sur le serveur
Write-Host "Creation du dossier sur le serveur..." -ForegroundColor Yellow
ssh -i $SshKey "$ServerUser@$ServerHost" "mkdir -p $RemotePath"

# Creer un archive temporaire
$tempArchive = "tickethic-deploy.tar.gz"
Write-Host "Creation de l'archive..." -ForegroundColor Yellow
tar -czf $tempArchive --exclude=node_modules --exclude=.next --exclude=.git --exclude="*.log" --exclude="*.tar.gz" .

# Copier l'archive sur le serveur
Write-Host "Copie de l'archive vers le serveur..." -ForegroundColor Yellow
scp -i $SshKey $tempArchive "$ServerUser@$ServerHost`:$RemotePath/"

# Deployer sur le serveur
Write-Host "Deploiement sur le serveur..." -ForegroundColor Yellow
ssh -i $SshKey "$ServerUser@$ServerHost" @"
cd $RemotePath
tar -xzf $tempArchive
rm $tempArchive
docker-compose down 2>/dev/null || true
docker-compose up --build -d
sleep 10
docker-compose ps
echo "Deploiement termine!"
echo "Application accessible sur: http://$ServerHost`:$LocalPort"
"@

# Nettoyer
Remove-Item $tempArchive -ErrorAction SilentlyContinue

Write-Host "Deploiement termine!" -ForegroundColor Green
Write-Host "Application accessible sur: http://$ServerHost`:$LocalPort" -ForegroundColor Cyan
